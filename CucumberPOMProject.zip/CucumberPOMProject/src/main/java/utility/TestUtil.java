package utility;

public class TestUtil extends TestBase {
	
	static int PAGE_TIME_OUT =20;
	static int IMPLICI_WAIT =30;
	
	public static String FirtNameSP = prop.getProperty("ShipingIfoName");
	public static String LastNameSP = prop.getProperty("ShippinginfoLname");
	public static String ZIPCODE = prop.getProperty("Zipcode");

}
